/* STORE PROJECT LEVEL CONSTANT FILE SUCH AS ENUM OR COMMON STRING VALUES. */

export const API_LIMIT = 10;
export const START_INDEX = 0;
export const MAX_API_LIMIT = 10000;
// export const API_BASE_URL = 'https://api.dev.bevisible.com/';
export const API_BASE_URL = process.env.REACT_APP_API_BASEURL;

