import axios from 'axios';
import { toast } from 'react-toastify';
import { API_BASE_URL } from './Constant';

const preLoginInstance = axios.create(
  {
    baseURL: API_BASE_URL,
    // headers: {
    //   'Content-Type': 'application/json',
    // }
  }
);

preLoginInstance.interceptors.response.use(undefined, (error) => {
  console.log('error', error);
  if (error.response) {
    toast.error(error.response.data.message || "Something went wrong. Please try again.");
  } else {
    toast.error("Something went wrong. Please try again.");
  }
  return Promise.reject(error);
});
export default preLoginInstance;
