import {GET_ALL_PRODUCT_PRICE} from "./ActionTypes";

export const getAllProductList = (payload) =>(
    console.log("payload",payload),
    {
    type: GET_ALL_PRODUCT_PRICE,
    payload,
})