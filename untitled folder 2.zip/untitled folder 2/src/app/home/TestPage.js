import React, { Component } from 'react'

export default class TestPage extends Component {
  render() {
    return (
      <div>
           <h2>Swapna</h2>
        <h2>Swapna</h2>
        <h2>Swapna</h2>
        <h2>Swapna</h2>
          TestPage</div>
    )
  }
}
