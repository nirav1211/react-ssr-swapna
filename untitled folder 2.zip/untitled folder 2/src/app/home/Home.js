import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {getAllProductList} from './HomeAction';
import {connect} from 'react-redux';
import {getAllProductListApi} from './Api';
import samsung from '../../assets/images/samsung.jpg';

class Home extends Component {
  constructor(props) {
    super(props);
    // component state
    this.state = {
      productList: [],
      // productList:[
      //   {
      //     "term": "24",
      //     "SwapEligible": false,
      //     "Sequence": 39,
      //     "seoName": "samsung-galaxy-a53",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbiQAE",
      //         "promoCode": "150_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WgOqQAK",
      //     "PreOwned": false,
      //     "OneTimePrice": 504,
      //     "Name": "Galaxy A53 5G",
      //     "MonthlyPrice": 21,
      //     "Make": "Samsung",
      //     "isUpgradeEligibleTo": false,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "flashSaleBanner": {
      //       "isFlashSaleEnabled": true,
      //       "flashSaleStartTime": "2022-04-13T00:00:00-04:00",
      //       "flashSaleShopText": "$150 gift card",
      //       "flashSalePDPText": "$150 gift card",
      //       "flashSaleEndTime": "2022-04-20T23:59:00-04:00",
      //       "countdownClockPreText": "End in"
      //     },
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 504,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/GalaxyA535G-AwesomeBlack-Front.jpg",
      //     "Code": "PRD_CD_Galaxy_A53_5G",
      //     "Available": true,
      //     "RetailPrice": 504
      //   },
      //   {
      //     "term": "24",
      //     "SwapEligible": false,
      //     "Sequence": 37,
      //     "seoName": "iphone-se-2022",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbdQAE",
      //         "promoCode": "200_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WfNzQAK",
      //     "PreOwned": false,
      //     "OneTimePrice": 429,
      //     "Name": "iPhone SE",
      //     "MonthlyPrice": 17.88,
      //     "Make": "Apple",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 429,
      //     "DeviceOS": "iOS",
      //     "ContentURL": "assets/images/iPhone_SE_2022_M_1.jpg",
      //     "Code": "PRD_CD_IPHONESE2022",
      //     "Available": true,
      //     "RetailPrice": 429
      //   },
      //   {
      //     "term": "36",
      //     "SwapEligible": false,
      //     "Sequence": 36,
      //     "seoName": "samsung-galaxy-s22-ultra",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbiQAE",
      //         "promoCode": "150_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WbCuQAK",
      //     "PreOwned": false,
      //     "OneTimePrice": 1200,
      //     "Name": "Galaxy S22 Ultra",
      //     "MonthlyPrice": 33.33,
      //     "Make": "Samsung",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 1200,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/GalaxyS22Ultra-Burgundy-Front.jpg",
      //     "Code": "PRD_CD_Galaxy_S22_ULTRA",
      //     "Available": true,
      //     "RetailPrice": 1200
      //   },
      //   {
      //     "term": "36",
      //     "SwapEligible": false,
      //     "Sequence": 35,
      //     "seoName": "samsung-galaxy-s22-plus",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbiQAE",
      //         "promoCode": "150_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000006MLBQQA4",
      //     "PreOwned": false,
      //     "OneTimePrice": 1008,
      //     "Name": "Galaxy S22+",
      //     "MonthlyPrice": 28,
      //     "Make": "Samsung",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 1008,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/GalaxyS22+-PhantomWhite-Front.jpg",
      //     "Code": "PRD_CD_Galaxy_S22_Plus",
      //     "Available": true,
      //     "RetailPrice": 1008
      //   },
      //   {
      //     "term": "24",
      //     "SwapEligible": false,
      //     "Sequence": 34,
      //     "seoName": "samsung-galaxy-s22",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbiQAE",
      //         "promoCode": "150_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000006MLBLQA4",
      //     "PreOwned": false,
      //     "OneTimePrice": 816,
      //     "Name": "Galaxy S22",
      //     "MonthlyPrice": 34,
      //     "Make": "Samsung",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 816,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/GalaxyS22-PhantomWhite-Front.jpg",
      //     "Code": "PRD_CD_Galaxy_S22",
      //     "Available": true,
      //     "RetailPrice": 816
      //   },
      //   {
      //     "term": "Pay in 4",
      //     "SwapEligible": false,
      //     "Sequence": 33,
      //     "seoName": "samsung-galaxy-a03s",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbnQAE",
      //         "promoCode": "50_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WbRHQA0",
      //     "PreOwned": false,
      //     "OneTimePrice": 169,
      //     "Name": "Galaxy A03s",
      //     "MonthlyPrice": 40,
      //     "Make": "Samsung",
      //     "isUpgradeEligibleTo": false,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": false,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 160,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/GalaxyA03s-Black-Front.jpg",
      //     "Code": "PRD_CD_Samsung_Galaxy_A03s",
      //     "Available": true,
      //     "RetailPrice": 160
      //   },
      //   {
      //     "term": "24",
      //     "SwapEligible": false,
      //     "Sequence": 32,
      //     "seoName": "google-pixel-6",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbjQAE",
      //         "promoCode": "100_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WQkoQAG",
      //     "PreOwned": false,
      //     "OneTimePrice": 600,
      //     "Name": "Pixel 6",
      //     "MonthlyPrice": 25,
      //     "Make": "Google",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 600,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/Pixel6-StormyBlack-Front.jpg",
      //     "Code": "PRD_CD_GOOGLEPIXEL6",
      //     "Available": true,
      //     "RetailPrice": 600
      //   },
      //   {
      //     "term": "24",
      //     "SwapEligible": false,
      //     "Sequence": 31,
      //     "seoName": "google-pixel-6-pro",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbjQAE",
      //         "promoCode": "100_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WQl3QAG",
      //     "PreOwned": false,
      //     "OneTimePrice": 888,
      //     "Name": "Pixel 6 Pro",
      //     "MonthlyPrice": 37,
      //     "Make": "Google",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": false,
      //     "DiscountedPrice": 888,
      //     "DeviceOS": "Android",
      //     "ContentURL": "assets/images/Pixel6Pro-CloudyWhite-Front.jpg",
      //     "Code": "PRD_CD_GOOGLEPIXEL6PRO",
      //     "Available": true,
      //     "RetailPrice": 888
      //   },
      //   {
      //     "term": "36",
      //     "SwapEligible": false,
      //     "Sequence": 30,
      //     "seoName": "iphone-13-pro",
      //     "Promotions": [
      //       {
      //         "redemptionCode": null,
      //         "promotionRedemptionLink": null,
      //         "promotionCategory": "Primary",
      //         "promoId": "a2s2G000004gGbjQAE",
      //         "promoCode": "100_CYOGC_3P",
      //         "portInRequired": true,
      //         "mdnType": "PORT IN"
      //       }
      //     ],
      //     "ProductId": "01t2G000004WMarQAG",
      //     "PreOwned": false,
      //     "OneTimePrice": 984,
      //     "Name": "iPhone 13 Pro",
      //     "MonthlyPrice": 30,
      //     "Make": "Apple",
      //     "isUpgradeEligibleTo": true,
      //     "isPromotionAvailable": true,
      //     "isComingSoon": false,
      //     "is5GCompatible": true,
      //     "financeFirst": true,
      //     "eSIMCompatible": true,
      //     "DiscountedPrice": 984,
      //     "DeviceOS": "iOS",
      //     "ContentURL": "assets/images/iPhone_13_Pro_ALP_1.jpg",
      //     "Code": "PRD_CD_IPHONE13PRO",
      //     "Available": true,
      //     "RetailPrice": 984
      //   },
      // ]
    };

}

  componentDidMount = () =>{
    this.props.getAllProductListApi();
    // console.log("this.props",this.props);
    // // axios.get("https://api.bevisible.com/v1/products/getProducts?BYOD=false")
    // const headers={
    //   'Authorization': 'Bearer AEvDoYnxDLpLgF1sS1R3VuzVCyo4',
    //   'Content-Type': 'application/json',
    //   'Origin': 'https://test2.bevisible.com/',
    // }
    // axios.get("https://api.dev.bevisible.com/v1/products/getProducts?BYOD=false",{headers})
    //   .then((res,dispatch)=>{
    //     console.log("res",res)
    //     dispatch(this.props.getAllProductList(res.data.HANDSET));
    //     // this.setState({productList: res.data.HANDSET})
    //   })
    //   .catch(err=>{
    //     console.log("err",err)
    //   })
  }
// REACT_APP_API_BASEURL=https://api.dev.bevisible.com/
  static loadData(match, dispatch){
    return Promise.all([
      dispatch(getAllProductListApi()),
    ]);
  }

  render() {
    console.log("this.props",this.props);
          const{productList} = this.props.homeState;
    return (
      <div className="smartphones-wrapper">
          {
            productList && productList.map((item, key)=>{
              return(
    <div className="smartphone-card" key={key}>
    {/* {
                  item.flashSaleBanner &&
              <div className="header">
                 <span>{item.flashSaleBanner.flashSaleShopText}</span>
    <span className="time">{item.flashSaleBanner.countdownClockPreText} 7d 11h 34m 22s</span>
              </div>
              }
              <div className="body">
    // <img src={`https://test2.bevisible.com/shop/${item.ContentURL}`} alt="mobile" className="product-image"/>
    <img src={samsung} alt="mobile" className="product-image"/>
    <h3 className="product-name">{item.Make + " " + item.Name}</h3>
    <h6 className="product-description">As low as ${item.MonthlyPrice}/mo for {item.term} months at 0% APR.</h6>
    <p className="product-price">
      Full Price:
      {item.OneTimePrice === item.DiscountedPrice
      ?
      "$" + item.DiscountedPrice
      :
      <>
      <span className="strike">${item.OneTimePrice}</span><span>${item.DiscountedPrice}</span>
      </>
      }</p>
              </div>
              <div className="footer">
              <span>$50 virtual gift card</span>
    <a href="/smartphones" className="time">See details</a>
              </div>*/}
              Name: {item.name}
            </div>
              )
            })
          }


    </div>
    )
  }
}

const mapStateToProps = state => ({
  homeState: state.HomeState
});
const mapDispatchToProps = {
  getAllProductListApi
}
Home.propTypes = {
  // getPosts: PropTypes.func
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);