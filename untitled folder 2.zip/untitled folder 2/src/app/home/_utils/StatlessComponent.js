import React from 'react';
import PropTypes from 'prop-types';

const ComponentName = props => {
    return (
        <div>
            ComponentName
        </div>
    );
};
ComponentName.propTypes = {
    // getPosts: PropTypes.func
};
export default ComponentName;