import { getAllProductList } from "./HomeAction";
import { PostLoginInstance } from "../../utils";
import preLoginInstance from "../../utils/PreLoginAxios";

export const getAllProductListApi = () => {
    return function (dispatch, getState) {
      let data = new URLSearchParams();
      data.append("start", 0);
      data.append("limit", 10);
      data.append("conditions", JSON.stringify([]));
      data.append("sorts", JSON.stringify([]));
        return PostLoginInstance.get("v2/users")
        // return preLoginInstance.get("entries")
            .then(res => {
              console.log('Helllooooo');
                // console.log('resssssss', res.data.data.data.results);
                // dispatch(getAllProductList(res.data.HANDSET));
                // dispatch(getAllProductList(res.data.data.data.results));
                dispatch(getAllProductList(res.data));
            });
    };
}