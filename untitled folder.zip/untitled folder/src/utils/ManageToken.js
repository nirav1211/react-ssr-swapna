export const deleteToken = () => {
  if (typeof window !== 'undefined') {
    
    deleteCookie();
   
  }
};




export const getToken = () => {
  const cookieToken = getCookieValue();
  console.log("Token",cookieToken);
  return cookieToken ? cookieToken : null
};


export const getCookieValue = (name = "token") => {
  if (typeof window !== 'undefined') {
    if (document.cookie.split(';').some((item) => item.trim().startsWith(`${name}=`))) {
      return document.cookie
        .split('; ')
        .find(row => row.startsWith(`${name}`))
        .split('=')[1];
    }
  }
  return null;
}

export const deleteCookie = (name = "token") => {
  // setCookie(name, "", { expires: -1 }); One of the way to delete is by
  // setting it empty and expire previous day
  document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

export const setCookie = (name, value, options = {}) => {
  options = {
    path: '/',
    // add other defaults here if necessary
    ...options
  };

  if (options.expires instanceof Date) {
    options.expires = options.expires.toUTCString();
  }

  if (typeof options.expires === 'number') {
    options.expires = new Date(Date.now() + options.expires * 864e5)
  }

  let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

  for (let optionKey in options) {
    updatedCookie += "; " + optionKey;
    let optionValue = options[optionKey];
    if (optionValue !== true) {
      updatedCookie += "=" + optionValue;
    }
  }

  // console.log("Inside cookie", updatedCookie);
  document.cookie = updatedCookie;
}