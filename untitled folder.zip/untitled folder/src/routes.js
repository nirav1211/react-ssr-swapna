import { Route } from 'react-router-dom';
import { PrivateRoute } from "./utils";
// import { Sandbox } from './utils/form';
import { Home } from './app/home';
import TestPage from './app/home/TestPage';

const routes = [
  {
    path: "/",
    name: "Home",
    type: Route,
    component: Home,
  },
  {
    path: "/test",
    name: "TestPage",
    type: Route,
    component: TestPage,
  },
  
];
export default routes