import { GET_ALL_PRODUCT_PRICE } from "./ActionTypes";
const INITIAL_STATE = {
   productList: [],
};
const HomeReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case GET_ALL_PRODUCT_PRICE:
            console.log("action",action);
            return{
                ...state,
                productList: action.payload
            }
        default:
            return state
    }
};
export default HomeReducer