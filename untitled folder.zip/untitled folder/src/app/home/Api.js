import { getAllProductList } from "./HomeAction";
import { PostLoginInstance } from "../../utils";
import preLoginInstance from "../../utils/PreLoginAxios";

export const getAllProductListApi = () => {
    return function (dispatch, getState) {
        return PostLoginInstance.get("v1/products/getProducts?BYOD=false")
        // return preLoginInstance.get("entries")
            .then(res => {
                console.log('res', res);
                dispatch(getAllProductList(res.data.HANDSET));
            });
    };
}