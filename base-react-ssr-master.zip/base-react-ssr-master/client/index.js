import React from 'react';
import { hydrate, render } from 'react-dom';
import { Provider } from 'react-redux';
import configureStore from '../src/store';
import App from '../src/App';
import { BrowserRouter } from 'react-router-dom';
import * as serviceWorker from '../src/serviceWorker';
import 'bootstrap3/dist/css/bootstrap.css';
import 'react-toastify/dist/ReactToastify.css';
import 'rc-slider/assets/index.css';
import '../src/assets/scss/style.scss';
import "react-datepicker/dist/react-datepicker.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const preloadedState = window.__PRELOADED_STATE__;

console.log("preloadedstate-->", preloadedState);

const renderMethod = module.hot ? render : hydrate;

// Allow the passed state to be garbage-collected
// delete window.__PRELOADED_STATE__;

renderMethod(
  <Provider store={configureStore(preloadedState)}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </Provider>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.register();
