const path = require('path');
const webpack = require('webpack');
const nodeExternals = require('webpack-node-externals');
const HtmlWebPackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const Dotenv = require('dotenv-webpack');
const WebpackPwaManifest = require('webpack-pwa-manifest')
const WorkboxPlugin = require('workbox-webpack-plugin');

const common = {
  rules: [
    {
      test: /\.(js)$/,
      exclude: /node_modules/,
      use: 'babel-loader'
    },
    {
      test: /\.(css|scss)$/,
      use: [
        // Creates `style` nodes from JS strings
        // 'style-loader',
        MiniCssExtractPlugin.loader,
        // Translates CSS into CommonJS
        'css-loader',
        // Compiles Sass to CSS
        'sass-loader',
      ],
    },
    {
      test: /\.(png|svg|jpg|gif|pdf)$/,
      use: [{
        loader: 'url-loader',
        options: {
          limit: 8192,
          outputPath: '../client_build/static/media/',
          publicPath: '/static/media/',
        },
      }],
    },
    {
      test: /\.(woff|woff2|eot|ttf|otf|flac|wav)$/,
      loader: 'file-loader',
      options: {
        outputPath: '../client_build/static/fonts/',
        publicPath: '/static/fonts/',
      }
    },
    {
      test: /\.(xml)$/,
      loader: 'file-loader',
      options: {
        outputPath: '../client_build/',
        publicPath: '/',
        name: 'sitemap.xml',
      }
    },
  ],
};


const optimization = {
  splitChunks: {
    chunks: 'async',
    minSize: 20000,
    maxSize: 244000,
    minChunks: 1,
    cacheGroups: {
      default: false,
      vendors: false,
      // vendor chunk
      vendor: {
        // sync + async chunks
        chunks: 'all',
        name: 'vendor',
        // import file path containing node_modules
        test: /node_modules/,
        priority: 20,
      },
      // common chunk
      common: {
        name: 'common',
        minChunks: 2,
        chunks: 'async',
        priority: 10,
        reuseExistingChunk: true,
        enforce: true
      },
    },
  },
}


const manifestOptions = {
  "short_name": "Kabego",
  "name": "Kabego",
  "icons": [
    {
      "src": './public/kabego-favicon-144_144.png',
      "size": "144x144",
      "type": "image/png"
    }
  ],
  "start_url": ".",
  "display": "standalone",
  "theme_color": "#000000",
  "background_color": "#ffffff"
}


const plugins = [
  // to generate index.html also
  new HtmlWebPackPlugin({
    template: './public/index.html',
    favicon: './public/kabego-favicon.png',
    filename: './index.html',
  }),

  // generate separate files for css and insert them using link tags
  new MiniCssExtractPlugin(),

  // environment files
  new Dotenv({
    path: process.env.NODE_ENV === "development" ?
      './src/env/.development' : './src/env/.production',
  }),

  // inserts manifest.json in head tag
  new WebpackPwaManifest(manifestOptions),

  // service worker by google
  new WorkboxPlugin.GenerateSW({
    // these options encourage the ServiceWorkers to get in there fast
    // and not allow any straggling "old" SWs to hang around
    clientsClaim: true,
    skipWaiting: true,
  }),
]


const clientConfig = {
  entry: './client/index.js',
  output: {
    path: path.resolve(__dirname, 'client_build'),
    // filename: 'client_bundle.js',
    filename: '[name].bundle.js',
    publicPath: '/'
  },
  module: common,
  devtool: process.env.NODE_ENV === 'development' ? 'inline-source-map' : false,
  devServer: {
    publicPath: '/', // path to bundle
    historyApiFallback: true,
    port: 3000,
    hot: true,
    inline: true,
    contentBase: './client_build',
  },
  optimization: optimization,
  plugins: plugins,
};

const serverConfig = {
  entry: './server/index.js',
  target: 'node',
  externals: [nodeExternals()],
  output: {
    path: path.resolve(__dirname, 'server_build'),
    filename: 'server_bundle.js',
    publicPath: '/'
  },
  module: common,
  devtool: process.env.NODE_ENV === 'development' ? 'inline-source-map' : false,
};

module.exports = [clientConfig, serverConfig];