export const deleteToken = () => {
  if (typeof window !== 'undefined') {
    deleteLocalData();
    deleteCookie();
    deleteCookie("user_type");
    deleteCookie("user_details");
  }
};


const deleteLocalData = () => {
  localStorage.removeItem('merchantMobile');
  localStorage.removeItem('user_details');
  localStorage.removeItem('pickUpLocation');
  localStorage.removeItem('latlng');
  localStorage.removeItem('pickUpLocationId');
  localStorage.removeItem('pickUpPlace');
  localStorage.removeItem('pickupBlockAddress');
  localStorage.removeItem('pickupContactPersonName');
  localStorage.removeItem('dropPlace');
  localStorage.removeItem('dropLocation');
  localStorage.removeItem('temp-pickUpLocationId');
  localStorage.removeItem('temp-pickUpPlace');
  localStorage.removeItem('temp-pickupBlockAddress');
  localStorage.removeItem('temp-pickupContactPersonName');
  localStorage.removeItem('temp-pickUpLocation');
  localStorage.removeItem('temp-latlng');
};


export const getToken = () => {
  const cookieToken = getCookieValue();
  return cookieToken ? cookieToken : null
};

export const setToken = data => {
  localStorage.setItem('token', data.key);
  localStorage.setItem('user_type', data.user_type);
  localStorage.setItem('user_details', JSON.stringify(data.user_details));
};



export const getCookieValue = (name = "token") => {
  if (typeof window !== 'undefined') {
    if (document.cookie.split(';').some((item) => item.trim().startsWith(`${name}=`))) {
      return document.cookie
        .split('; ')
        .find(row => row.startsWith(`${name}`))
        .split('=')[1];
    }
  }
  return null;
}

export const deleteCookie = (name = "token") => {
  // setCookie(name, "", { expires: -1 }); One of the way to delete is by
  // setting it empty and expire previous day
  document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

export const setCookie = (name, value, options = {}) => {
  options = {
    path: '/',
    // add other defaults here if necessary
    ...options
  };

  if (options.expires instanceof Date) {
    options.expires = options.expires.toUTCString();
  }

  if (typeof options.expires === 'number') {
    options.expires = new Date(Date.now() + options.expires * 864e5)
  }

  let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);

  for (let optionKey in options) {
    updatedCookie += "; " + optionKey;
    let optionValue = options[optionKey];
    if (optionValue !== true) {
      updatedCookie += "=" + optionValue;
    }
  }

  // console.log("Inside cookie", updatedCookie);
  document.cookie = updatedCookie;
}


export const getUserType = () => {
  // return localStorage.getItem('user_type');
  return getCookieValue("user_type");
}

export const getUserDetails = () => {
  return JSON.parse(localStorage.getItem('user_details'));
  //return JSON.parse(decodeURIComponent(getCookieValue("user_details"))) || {};
}