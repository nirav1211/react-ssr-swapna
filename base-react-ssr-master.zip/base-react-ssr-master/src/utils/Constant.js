/* STORE PROJECT LEVEL CONSTANT FILE SUCH AS ENUM OR COMMON STRING VALUES. */

export const API_LIMIT = 10;
export const START_INDEX = 0;
export const MAX_API_LIMIT = 10000;
// export const API_BASE_URL = 'http://3.7.185.1/api/';
export const API_BASE_URL = process.env.REACT_APP_API_BASEURL;

export const handledBy = {
  PERSONAL: 1,
  COMPANY: 2,
  _presentable: {
    1: 'Personal',
    2: 'Company',
  }
}


export const OrderType = {
  ACTIVE: 1,
  UPCOMING: 2,
  PAST: 3,
}

export const OrderStatus = {
  SCHEDULED: 5,
  PLACED: 10,
  ASSIGNED: 20,
  ACCEPTED: 30,
  DECLINED: 40,
  GOING_TO_PICK_UP: 50,
  PICKED_UP: 60,
  DELIVERED: 70,
  COMPLETED: 80,
  CANCELLED: 90,
  _presentable: {
    5: 'Order Scheduled',
    10: 'Order Placed',
    20: 'Order Assigned',
    30: 'Order Assigned',
    40: 'Order Declined',
    50: 'Order Assigned',
    60: 'Order Picked up',
    70: 'Order Delivered',
    80: 'Order Completed',
    90: 'Order Cancelled',
  },
  _holdingText: {
    // 30: 'Waiting for Rider to arrive/accept',
    20: 'Waiting for rider to accept',
    60: 'Going to pick up',
    70: 'Delivering order',
    80: "Arriving with cash"
  },
  getText: function (value) {
    return this._presentable[value];
  },
  getHoldingText: function (value) {
    return this._holdingText[value];
  }
}


export const LocationUsageIn = {
  SIGNUP: 1,
  CREATEORDER: 2,
  PICKUP: 3
}

export const planDuration = {
  HOURLY: 10,
  DAILY: 20,
  WEEKLY: 30,
  MONTHLY: 40,
  _presentable: {
    10: "1 Hour",
    20: "1 Day",
    30: "7 Days",
    40: "30 Days",
  }
}

export const ruleOn = {
  ORDER_COUNT: 10,
  MAX_KMS: 20,
  MIN_KMS: 30,
  _presentable: {
    10: "No. of Orders",
    20: "Maximum Kilometers",
    30: "Minimum Kilometers",
  }
}