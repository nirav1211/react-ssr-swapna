import { Route } from 'react-router-dom';
import { PrivateRoute } from "./utils";
import { Sandbox } from './utils/form';
import { Home } from './app/home';

const routes = [
  {
    path: "/",
    name: "Home",
    type: Route,
    component: Home,
  },
  {
    path: "/sandbox",
    name: "Sandbox",
    type: Route,
    component: Sandbox
  }
];
export default routes