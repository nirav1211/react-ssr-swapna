import React from 'react';
import { Switch } from 'react-router-dom';
import routes from "./routes";
import { ToastContainer } from 'react-toastify';

function App() {
  return (
    <>
      <Switch>
        {
          routes.map((prop, key) => {
            return (
              <prop.type exact path={prop.path} key={key} component={prop.component} />
            )
          })
        }
      </Switch>
      <ToastContainer
        toastClassName="custom-toastify"
        position="top-right"
        hideProgressBar />
    </>
  );
}

export default App;
